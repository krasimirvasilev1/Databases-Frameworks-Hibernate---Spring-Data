create trigger tr_deleted_employees
  after DELETE
  on employees
  for each row
  BEGIN
INSERT INTO deleted_employees(employee_id,
first_name,last_name,middle_name,job_title,department_id,salary)
VALUES(OLD.employee_id,
OLD.first_name,OLD.last_name,OLD.middle_name,OLD.job_title,OLD.department_id,OLD.salary);
END;

